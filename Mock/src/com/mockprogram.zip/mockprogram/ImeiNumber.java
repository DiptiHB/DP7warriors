package com.mockprogram;
import java.util.Scanner;
public class ImeiNumber {
	
	static void checkIMEInum(long num)
	{
		int count=0;
		int sum=0;
		
		while (num!=0)
		{
			num/=10;
		    count++;
		
			    if (count==15)
			    {
				sum+=num%10;
				System.out.println("The Sum of Num is: "+sum);
				
				if(sum%10==0)
				{
					System.out.println("Your IMEI Number is Valid.");
				}
				
				else 
				{
					System.out.println("Invalid IMEI number.");
				}
		}
	}
}

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter 15 digit number: ");
		long num=sc.nextLong();
		checkIMEInum(num);

	}

}
